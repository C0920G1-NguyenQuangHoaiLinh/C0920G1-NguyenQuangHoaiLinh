package bo;

public interface IContractDetailBO {

}
